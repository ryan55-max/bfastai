document.addEventListener('DOMContentLoaded', () => {
  const introAnimation = document.querySelector('.intro-animation');
  const introText = document.querySelector('.intro-text');
  const mainContent = document.querySelector('.main-content');
  const glow = document.querySelector('.glow-background');

  // Show glow effect immediately
  glow.style.opacity = '0.8';

  // Delayed intro text animation
  setTimeout(() => {
    introText.style.animation = 'fadeInUp 0.8s ease forwards';
    
    // Fade out intro text
    setTimeout(() => {
      introText.style.animation = 'fadeOutUp 0.8s ease forwards';
      
      // After intro text fades out
      setTimeout(() => {
        introAnimation.style.display = 'none';
        mainContent.style.opacity = '1';
        
        // Animate hero content
        const heroContent = document.querySelector('.hero-content');
        heroContent.style.animation = 'slideInFromRight 1s ease forwards';

        // Initialize scroll animations
        initScrollAnimations();
      }, 800);
    }, 2000);
  }, 500);

  const integrationsContainer = document.querySelector('.integrations-container');
  const testimonialsContainer = document.querySelector('.testimonials-container');
  
  if (integrationsContainer) {
    const content = integrationsContainer.innerHTML;
    integrationsContainer.innerHTML = content + content;
  }
  
  if (testimonialsContainer) {
    const content = testimonialsContainer.innerHTML;
    testimonialsContainer.innerHTML = content + content;
  }

  // Add smooth scroll for navigation links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });

  // Initialize clock
  updateLocalTime();

  const hamburger = document.querySelector('.hamburger-menu');
  const mobileNav = document.querySelector('.mobile-nav');
  const body = document.body;

  if (hamburger && mobileNav) {
    hamburger.addEventListener('click', () => {
      hamburger.classList.toggle('active');
      mobileNav.classList.toggle('active');
      body.style.overflow = mobileNav.classList.contains('active') ? 'hidden' : '';
    });

    // Close mobile menu when clicking on any link
    mobileNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        hamburger.classList.remove('active');
        mobileNav.classList.remove('active');
        body.style.overflow = '';
        
        // If it's the home link, scroll to top smoothly
        if (link.getAttribute('href') === '#' || link.getAttribute('href') === '/') {
          window.scrollTo({
            top: 0,
            behavior: 'smooth'
          });
        }
      });
    });
  }
});

function initScrollAnimations() {
  const sections = {
    'features': 'fade-in-up',
    'features-key': 'fade-in-left',
    'integrations': 'fade-in-right', 
    'testimonials': 'fade-in-scale',
    'contact': 'fade-in-bottom'
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const section = entry.target;
        const animationClass = sections[section.id];
        if (animationClass) {
          section.classList.add('animate', animationClass);
        }
        
        // Animate children with delay
        const children = section.querySelectorAll('.scroll-animate');
        children.forEach((child, index) => {
          setTimeout(() => {
            child.classList.add('animate');
          }, index * 200);
        });

        observer.unobserve(section);
      }
    });
  }, {
    threshold: 0.2,
    rootMargin: '0px 0px -50px 0px'
  });

  // Observe sections
  Object.keys(sections).forEach(sectionId => {
    const section = document.getElementById(sectionId);
    if (section) {
      observer.observe(section);
    }
  });

  // Observe individual elements
  const animatedElements = document.querySelectorAll('.scroll-animate');
  animatedElements.forEach(element => {
    observer.observe(element);
  });
}

// Add clock update function
function updateLocalTime() {
  const timeElement = document.getElementById('local-time');
  const options = {
    timeZone: 'GMT',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  };
  
  function update() {
    const time = new Date().toLocaleTimeString('fr-FR', options);
    timeElement.textContent = `Heure locale (GMT): ${time}`;
  }
  
  update();
  setInterval(update, 1000);
}